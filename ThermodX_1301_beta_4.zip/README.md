
![IMG_20210105_222157_267](https://user-images.githubusercontent.com/91332949/135549028-10fc6e51-ac78-4044-a6a3-9bf0df8f5db5.png)

 <img src="https://img.shields.io/github/stars/UsiFX/ThermodX-Source?style=flat&logo=github&color=yellow" /> </a>
<a href="https://github.com/UsiFX/ThermodX-Source/network/members" alt="GitHub forks"> <img src="https://img.shields.io/github/forks/UsiFX/ThermodX-Source" /> </a> <a href="https://github.com/UsiFX/ThermodX-Source/graphs/contributors" alt="GitHub contributors"> <img src="https://img.shields.io/github/contributors/UsiFX/ThermodX-Source?style=flat&logo=github" /> </a>
<a href="https://github.com/UsiFX/ThermodX-Source" alt="GitHub closed pull requests"> <img src="https://img.shields.io/github/issues-pr-closed-raw/UsiFX/ThermodX-Source?color=success" /> </a> <img src="https://img.shields.io/badge/maintained%3F-yes-blue.svg" /> </a> <a href="https://www.pling.com/p/1609396/"><img src="https://img.shields.io/badge/Download-Module-red.svg"></a> <br/>


### This project is currently under beta testing, final version will be available soon!
---------------------------------------------------------------------------------------
## Description:
### ThermodX is a modded thermal engine for some selected devices (will be adding more devices in the future)
### and designed for better and optimal performance by tweaking the kernel!

## Supported Thermal engines (as of now):
#### > Snapdragon 820
#### > Snapdragon 720G
#### > Snapdragon 710
#### > Snapdragon 660
#### > Snapdragon 430
#### > Snapdragon 425

## Features/Tweaks included in this module rather than modded thermals:
#### Kernel tweaks & network tweaks for now

## Requirements:
#### Magisk v19.0 or higher

## Changelogs & Credits:
#### Will be available in final release :D
-------------------------------------------------------------------------------------
## Official Support:
 <a href="https://t.me/xprjkts">Official Telegram Channel</a>
 
 <a href="https://t.me/xprjkts_chat">Official Telegram Chat</a>
 
 <a href="https://t.me/imUsif12">Telegram Account</a>
